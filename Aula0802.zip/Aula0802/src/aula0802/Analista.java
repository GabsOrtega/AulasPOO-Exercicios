package aula0802;

public class Analista extends Empregado {
    private float valorPorProjeto[];
    
    public Analista(){}
    
    public Analista(String n, String m, float[] vP){
        super.setNome(n);
        super.setMatricula(m);
        this.valorPorProjeto = vP;
    }

    public float[] getValorPorProjeto() {
        return valorPorProjeto;
    }

    public void setValorPorProjeto(float[] valorPorProjeto) {
        this.valorPorProjeto = valorPorProjeto;
    }

    @Override
    public float calculaSalario() {
        float sal = 0;
        
        for (int i=0; i < valorPorProjeto.length; i++) {
            sal += valorPorProjeto[i];
        }
        
        return sal;
    }
    
}
