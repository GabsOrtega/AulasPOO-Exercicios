package aula0502;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Aula0502 {


    public static void main(String[] args) {
        Triangulo t1 = new Triangulo(3.14, 8.95);
        
        Triangulo t2 = new Triangulo();
                   
        double n, n2;
        n = Double.parseDouble(JOptionPane.showInputDialog("Digite a base do triângulo"));
        n2 = Double.parseDouble(JOptionPane.showInputDialog("Digite a altura do triângulo"));

        t2.setBase(n);
        t2.setAltura(n2);
        
        t1.imprimeDados();
        t2.imprimeDados();
        
    }
    
}
