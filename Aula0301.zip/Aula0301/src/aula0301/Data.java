
package aula0301;

import java.util.Scanner;
import javax.swing.JOptionPane;


public class Data {
   int dia, mes, ano;
    
   public Data(){
       
   }
   
   public Data(int d, int m, int a) {
       this.dia = d;
       this.mes = m;
       this.ano = a;
   }
   
   public void cadastraDados() {
       this.dia = Integer.parseInt(JOptionPane.showInputDialog("Digite o dia"));
       
       this.mes = Integer.parseInt(JOptionPane.showInputDialog("Digite o mês"));
       
       this.ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano"));
       
   }
   
   public void imprimeData(){
       System.out.println(this.dia + "/" + this.mes + "/" + this.ano);
   }
}
