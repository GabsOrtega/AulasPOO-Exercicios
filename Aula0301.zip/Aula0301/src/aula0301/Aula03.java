
package aula0301;


public class Aula03 {


    public static void main(String[] args) {
       Triangulo t = new Triangulo();
       t.altura = 10f;
       t.base = 20f;
       Triangulo t1 = new Triangulo(25.5f, 22f);
       
       Data d = new Data();
       Data d1 = new Data(02, 04, 2024);
       
       t.calculaArea();
       System.out.println(t.imprimeDados());
       
       t1.calculaArea();
       System.out.println(t1.imprimeDados());
       
       d.cadastraDados();
       d.imprimeData();
       
       d1.imprimeData();
    }
    
}
