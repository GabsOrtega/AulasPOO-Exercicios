
package aula0301;

public class Triangulo {
    float base;
    float altura;
    
    public Triangulo(){
        
    }
    
    public Triangulo(float b, float a){
        this.base = b;
        this.altura = a;
    }
    
     public float calculaArea(){
        return (this.base * this.altura) / 2;
    }
    
    public String imprimeDados(){
        return "A area do triangulo de base " + this.base + " e altura " + this.altura + " e igual a " + this.calculaArea();
    }

    
}
