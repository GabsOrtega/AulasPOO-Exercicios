package aula0504;

public class Vendedor {
    private float vendas;
    private float salario;
    private String nome;
    private int falta;

    public Vendedor(float v, float s, String n, int f) {
        this.vendas = v;
        this.salario = s;
        this.nome = n;
        this.falta = f;
    }

    public float getVendas() {
        return this.vendas;
    }

    public void setVendas(float v) {
        this.vendas = v;
    }

    public float getSalario() {
        return this.salario;
    }

    public void setSalario(float s) {
        this.salario = s;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String n) {
        this.nome = n;
    }

    public int getFalta() {
        return this.falta;
    }

    public void setFalta(int f) {
        this.falta = f;
    }
    
    public void imprimirDados() {
        System.out.println("---- Vendedor ----");
        System.out.println("Nome: " + this.getNome());
        System.out.println("Salario: " + this.getSalario());
        System.out.println("Vendas: " + this.getVendas());
        System.out.println("Faltas: " + this.getFalta());
        System.out.println("Comissao: " + this.calcularComissao());
        System.out.println("Desconto Falta: " + this.descontoFalta());
        System.out.println("Novo Salario: " + this.calcularSalario());
        System.out.println("");
        
    }
    
    public float calcularSalario() {
        float sal = (this.getSalario() + this.calcularComissao() - this.descontoFalta());
        return sal;
    }
    
    public float calcularComissao() {
        if (this.getVendas() >= 1000 && this.getVendas() < 2000) {
            return (this.getVendas() * 0.1f);
        }
        
        else if (this.getVendas() >= 2000) {
            return (this.getVendas() * 0.15f);
        }
        
        return 0;
    }
    
    public float descontoFalta() {
        float desc = (this.getSalario() / 30) * this.getFalta();
        return desc;
    }
}
