
package aula0504;


public class Aula0504 {

    public static void main(String[] args) {
     Vendedor v = new Vendedor(1000f, 2500f, "Ortega", 20);
     Vendedor v1 = new Vendedor(2000f, 1500f, "Bruno", 10);
     
     v.imprimirDados();
     v1.imprimirDados();
    }
    
}
