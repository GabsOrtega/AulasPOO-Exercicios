package aula0602;

import javax.swing.JOptionPane;

public class Aula0602 {


    public static void main(String[] args) {
        String nomeA = JOptionPane.showInputDialog("Digite o nome do Analista");
        String matriculaA = JOptionPane.showInputDialog("Digite a matricula do Analista");
        float qtdProjetos = Float.parseFloat(JOptionPane.showInputDialog("Digite a quantidade de projetos"));
        
        int tam = (int) Math.ceil(qtdProjetos);
        float[] valorPorProjeto = new float[tam];
        
        for (int i=0; i < qtdProjetos; i++) {
            valorPorProjeto[i] = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor do " + (i+1) + "° projeto"));
        }
        
        Analista ana = new Analista(nomeA, matriculaA, valorPorProjeto);
        
        String nomeP = JOptionPane.showInputDialog("Digite o nome do Programador");
        String matriculaP = JOptionPane.showInputDialog("Digite a matricula do Programador");
        int qtdHoras = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de horas trabalhadas"));
        float valorHora = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor da hora trabalhada"));
        
        Programador prog = new Programador(nomeP, matriculaP, qtdHoras, valorHora);
        
        JOptionPane.showMessageDialog(null, "Analista " + "\nNome: " + ana.getNome()
                + "\nMatricula " + ana.getMatricula() + "\nSalário: " + ana.calculaSalario()
                + "\n\nProgramador \nNome: " + prog.getNome() + "\nMatricula: " + prog.getMatricula() +
                "\nSalário: " + prog.calculaSalario());
        
        
    }
    
}
