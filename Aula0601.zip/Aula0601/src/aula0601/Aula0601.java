package aula0601;

import javax.swing.JOptionPane;

public class Aula0601 {

    public static void main(String[] args) {
        
        float raioC, baseR, alturaR;
        
        raioC = Float.parseFloat(JOptionPane.showInputDialog("Digite o raio da circunferencia"));
        
        baseR = Float.parseFloat(JOptionPane.showInputDialog("Digite a base do retângulo"));
        alturaR = Float.parseFloat(JOptionPane.showInputDialog("Digite a altura do retângulo"));
        
        Circunferencia c = new Circunferencia(raioC);
        
        Retangulo r = new Retangulo(baseR, alturaR);
        
        c.mostra();
        r.mostra();
        
        
    }
    
}
