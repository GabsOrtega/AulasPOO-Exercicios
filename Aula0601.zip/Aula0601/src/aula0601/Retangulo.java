package aula0601;

public class Retangulo extends Triângulo {
 
    public Retangulo(float b, float a) {
        super(b, a);
    }
    
    public float area(){
        float area = super.getBase() * super.getAltura();
        return area;
    }
    
    public float perimetro() {
        float perimetro = 2 * (super.getBase() * super.getAltura());
        return perimetro;
    }
    
    
    public void mostra() {
        System.out.println("---- Retangulo ----");
        System.out.println("Base: " + super.getBase());
        System.out.println("Altura: " + super.getAltura());
        System.out.println("Area: " + area());
        System.out.println("Perimetro: " + perimetro());
        System.out.println("");
    }
 
    
}
