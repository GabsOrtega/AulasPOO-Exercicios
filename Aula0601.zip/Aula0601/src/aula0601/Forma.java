package aula0601;


public abstract class Forma {
    public abstract float area();
    public abstract void mostra();
    public float perimetro(){ return 0f; }
}



