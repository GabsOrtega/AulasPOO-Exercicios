package aula0601;


public class Triângulo extends Forma {
    private float base;
    private float altura;

    public Triângulo(float b, float a) {
        this.base = b;
        this.altura = a;
    }

    public float getBase() {
        return this.base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAltura() {
        return this.altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    @Override
    public float area() {
        return (this.getBase() * this.getAltura()) / 2;
    }

    @Override
    public void mostra() {
        System.out.println("Triangulo:");
        System.out.println("Base: " + this.getBase());
        System.out.println("Altura: " + this.getAltura());
        System.out.println("Área: " + this.area());
    }

    
}
