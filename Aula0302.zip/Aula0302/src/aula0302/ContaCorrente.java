
package aula0302;

import java.util.Scanner;
import javax.swing.JOptionPane;


public class ContaCorrente {
    String nome;
    float saldo;
    float limite;
    char tipo;
    
    public ContaCorrente(){
        
    }
    
    public ContaCorrente(String n, float s, float l, char t){
        this.nome = n;
        this.saldo = s;
        this.limite = l;
        this.tipo = t;
    }
    
    public ContaCorrente(String n, float s, char t){
        this.nome = n;
        this.saldo = s;
        this.tipo = t;
    }
    
    public void cadastraDados(){
        this.nome = JOptionPane.showInputDialog("Digite seu nome");
        
        this.saldo = Float.parseFloat(JOptionPane.showInputDialog("Digite seu saldo"));
       
        this.limite = Float.parseFloat(JOptionPane.showInputDialog("Digite o limite da sua conta"));
        
        this.tipo = JOptionPane.showInputDialog("Digite o tipo da sua conta ").charAt(0);
    }
    
    public String imprimeDados(){
        return "\nDados: \nNome: " + this.nome + "\nSaldo: " + this.saldo + "\nLimite: "
                + this.limite + "\nTipo: " + this.tipo;
    }
    
    public void depositar(float valor){
        this.saldo += valor;
    }
    
    public void sacar(float valor){
        this.saldo -= valor;
               
    }
            
}
