
package aula0302;


public class Aula0302 {

    public static void main(String[] args) {
       ContaCorrente c = new ContaCorrente("Ortega", 2000f, 5000f, '1');
       ContaCorrente c2 = new ContaCorrente();
       
       c.depositar(30f);
       c.sacar(200f);
       System.out.println(c.imprimeDados());
       
       c2.cadastraDados();
       c2.depositar(100f);
       c2.sacar(50f);
       System.out.println(c2.imprimeDados());
       
       
       
       
    }
    
}
