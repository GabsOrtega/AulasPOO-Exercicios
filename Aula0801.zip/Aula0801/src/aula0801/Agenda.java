package aula0801;

import javax.swing.JOptionPane;

public class Agenda {
    private String dados[][];
    
    public Agenda(){}
    
    public Agenda(String dados[][]){
        this.dados = dados;
    }

    public String[][] getDados() {
        return dados;
    }

    public void setDados(String[][] dados) {
        this.dados = dados;
    }
    
    public void entDados(){
        int pessoas = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade de pessoas a ser cadastradas"));
        dados = new String[pessoas][2];
        
        for(int i=0; i < pessoas; i++) {
           String nome = JOptionPane.showInputDialog("Digite seu nome");
           String telefone = JOptionPane.showInputDialog("Digite seu telefone");
           dados[i][0] = nome;
           dados[i][1] = telefone;
        }
        
    }
    
    public void imprimir(){
         System.out.println("----- Agenda =----");
        for(int i=0; i < dados.length; i++) {
           System.out.println("\nNome: " + dados[i][0]);
           System.out.println("Telefone: " + dados[i][1]);
        }
    
    }
    
    public String busca(String nome){
        for(int i=0; i < dados.length; i++) {
            if (dados[i][0].equals(nome)) {
                return "\n---- Busca encontrada ---- \nNome: " + dados[i][0] + "\nTelefone: " + dados[i][1];
            }
        }
        
        return "\n---- Busca não encontrada ----";
    }
}
