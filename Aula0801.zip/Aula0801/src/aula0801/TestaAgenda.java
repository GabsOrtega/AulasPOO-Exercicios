package aula0801;

import javax.swing.JOptionPane;

public class TestaAgenda {

    public static void main(String[] args) {
       
            
           Agenda ag = new Agenda();
           ag.entDados();
           ag.imprimir();
           System.out.println(ag.busca("Gabriel"));      
        }
    }
    
