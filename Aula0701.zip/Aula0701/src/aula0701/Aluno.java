package aula0701;

import javax.swing.JOptionPane;

public class Aluno extends Pessoa {
    private String rgm;

    public Aluno() {}

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }
    
    
    @Override
    public String mostraClasse() {
        return "Classe Aluno";
    }
    
}
