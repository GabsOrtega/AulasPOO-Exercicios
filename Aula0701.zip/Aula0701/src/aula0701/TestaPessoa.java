package aula0701;

import javax.swing.JOptionPane;

public class TestaPessoa {

    public static void main(String[] args) {
        Pessoa p = null;
        
        while (true) {
            int tipo = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite uma opção: " +
                    "\n1 - Aluno"
                    + "\n2 - Professor "
                    + "\n3 - Funcionario"
                    + "\n4 - Sair"));
            
            switch (tipo) {
                case 1:
                    p = new Aluno();
                    break;
                case 2:
                    p = new Professor();
                    break;
                case 3:
                    p = new Funcionario();
                    break;
                case 4:
                    System.out.println("Bye... bye");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opção inválida");
                    System.exit(0);
            }
            
           JOptionPane.showMessageDialog(null, p.mostraClasse());
        }
        
         
        
        
    }
    
}
