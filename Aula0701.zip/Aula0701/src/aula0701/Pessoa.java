package aula0701;

public abstract class Pessoa {
    private String nome;
    
    public Pessoa(){}

    public String getNome() {
        return nome;
    }

    public void setNome(String n) {
        this.nome = n;
    }
    
    public abstract String mostraClasse();
    
    
}
