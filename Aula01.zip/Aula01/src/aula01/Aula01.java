
package aula01;


public class Aula01 {

    public static void main(String[] args) {
       Cliente c = new Cliente();
       c.nome = "Orteguinhas";
       c.email = "gabs@gmail.com";
       c.endereco = "Rua Palmirinha 703";
       c.telefone = "11 99999-9999";
       
       Curso curso = new Curso();
       
       curso.nome = "Ciencia da Computacao";
       curso.qtddealunos = 100;
       curso.turma = "3F";
       
       System.out.println("---- Cliente ----");
       System.out.println(c.nome);
       System.out.println(c.email);
       System.out.println(c.endereco);
       System.out.println(c.telefone);
       
       System.out.println("\n---- Curso ----");
       System.out.println(curso.nome);
       System.out.println(curso.qtddealunos);
       System.out.println(curso.turma);
       
    }
    
}
