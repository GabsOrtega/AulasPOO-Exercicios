package aula01;

public class Curso {
    String nome;
    int qtddealunos;
    String turma;
}
