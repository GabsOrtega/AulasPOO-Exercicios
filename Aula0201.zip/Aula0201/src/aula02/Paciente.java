
package aula02;


public class Paciente {
    String nome;
    String rg;
    String endereco;
    String telefone;
    String dataNascimento;
    String profissao;
    
    public Paciente(){}
    
    public Paciente(String n) {
        this.nome = n;
    }
}
