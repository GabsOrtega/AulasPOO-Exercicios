
package aula02;

import java.util.Scanner;

public class Aula02 {

    public static void main(String[] args) {
       String nome;
       Scanner teclado = new Scanner(System.in);
       
       System.out.println("Digite o seu nome");
       nome = teclado.nextLine();
       
       Paciente p = new Paciente();
       p.nome = "Ortega";
       p.rg = "00.000.000-0";
       p.endereco = "Rua do Sertao";
       p.telefone = "11 99999-9999";
       p.dataNascimento = "00/00/0000";
       p.profissao = "Desenvolvedor";
       
       Paciente p1 = new Paciente(nome);
       p1.rg = "12.345.678-9";
       p1.endereco = "Rua do Jose";
       p1.telefone = "11 12345-6789";
       p1.dataNascimento = "01/12/2000";
       p1.profissao = "Administrador";
       
       System.out.println("\nDados do primeiro paciente: ");
       System.out.println("Nome: " + p.nome);
       System.out.println("RG: " + p.rg);
       System.out.println("Endereco " + p.endereco);
       System.out.println("Telefone" + p.telefone);
       System.out.println("Data de Nascimento: " + p.dataNascimento);
       System.out.println("Profissao: " + p.profissao);
      
       System.out.println("\nDados do segundo paciente: ");
       System.out.println("Nome: " + p1.nome);
       System.out.println("RG: " + p1.rg);
       System.out.println("Endereco " + p1.endereco);
       System.out.println("Telefone" + p1.telefone);
       System.out.println("Data de Nascimento: " + p1.dataNascimento);
       System.out.println("Profissao: " + p1.profissao);
       
       
    }
    
}
