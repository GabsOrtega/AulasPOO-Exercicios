package aula0501;

public class Aula05 {

    public static void main(String[] args) {
        Funcionario f = new Funcionario();
        Funcionario f1 = new Funcionario(12345, 2500f, "Desenvolvedor Junior");
        
        f.setCracha(1234);
        f.setSalario(2700f);
        
        System.out.println("---- Funcionario 1 ----");
        System.out.println("Cracha: " + f.getCracha());
        System.out.println("Cargo: " + f.getCargo());
        System.out.println("Salario: " + f.getSalario());
        System.out.println("Aumento percentual no salario: " + f.calculaAumento(50f));
        System.out.println("Aumento ano trabalhado salario: " + f.calculaAumento(5));
        
        System.out.println("\n---- Funcionario 2 ----");
        System.out.println("Cracha: " + f1.getCracha());
        System.out.println("Salario: " + f1.getSalario());
        System.out.println("Cargo: " + f1.getCargo());
        System.out.println("Salario: " + f1.getSalario());
        System.out.println("Aumento percentual no salario: " + f1.calculaAumento(20f));
        System.out.println("Aumento ano trabalhado salario: " + f1.calculaAumento(2));
        

    }
    
}
