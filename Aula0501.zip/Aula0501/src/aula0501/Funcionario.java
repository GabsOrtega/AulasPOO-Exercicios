
package aula0501;

public class Funcionario {
    private int cracha;
    private float salario;
    private String cargo;
    
    
    public Funcionario(){
        this.setCargo("Assistente");
    }

    public int getCracha() {
        return this.cracha;
    }

    public void setCracha(int cracha) {
        this.cracha = cracha;
    }

    public float getSalario() {
        return this.salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return this.cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    public Funcionario(int c, float s, String car){
        this.cracha = c;
        this.salario = s;
        this.cargo = car;
    }
    
    public float calculaAumento(float porcentagem) {
        float aumento = this.getSalario() * (porcentagem/100);
        return (this.getSalario() + aumento);
    }
    
    public float calculaAumento(int tempo) {
        float aumento = 150 * tempo; 
        return (this.getSalario() + aumento);
    }
}
