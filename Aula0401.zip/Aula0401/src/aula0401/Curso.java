
package aula0401;

import javax.swing.JOptionPane;

public class Curso {
    String nome;
    int quantidadedealunos;
    String turma;
    float mensalidade;
    
    public Curso(){}
    
    public Curso(String n, int q, String t, float m){
        this.nome = n;
        this.quantidadedealunos = q;
        this.turma = t;
        this.mensalidade = m;
    }
    
    void cadastraCurso(){
        this.nome = JOptionPane.showInputDialog("Digite o nome do curso");
        
        this.quantidadedealunos = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de alunos do curso"));
        
        this.turma = JOptionPane.showInputDialog("Digite a turma do curso");
        
        this.mensalidade = Float.parseFloat(JOptionPane.showInputDialog("Digite a mensalidade do curso"));
    }
    
    void imprimeDados(){
        System.out.println("\n---- Curso ----");
        System.out.println("Nome: " + this.nome);
        System.out.println("Quantidade de alunos: " + this.quantidadedealunos);
        System.out.println("Turma: " + this.turma);
        System.out.println("Mensalidade: " + this.mensalidade);
        System.out.println("Mensalidade Total: " + this.calculaTotalMensalidade());
    }
    
    float calculaTotalMensalidade() {
        return this.mensalidade * this.quantidadedealunos;
    }
    
    
}
