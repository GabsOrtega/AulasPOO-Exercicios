package aula0401;

public class Aula04 {

    public static void main(String[] args) {
       Curso c1 = new Curso("Ciencia da Computacao", 100, "3f", 400);
       Curso c2 = new Curso();
       
       c1.imprimeDados();
       c2.cadastraCurso();
       c2.imprimeDados();
       
       
    }
    
}
