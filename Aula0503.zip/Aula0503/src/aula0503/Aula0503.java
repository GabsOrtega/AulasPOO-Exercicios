package aula0503;

public class Aula0503 {

    public static void main(String[] args) {
        Torneio t1 = new Torneio("Ortega", 19);
        
        Torneio t2 = new Torneio("Bruno", 50);
        
        t1.imprimeDados();
        t2.imprimeDados();
    }
    
}
