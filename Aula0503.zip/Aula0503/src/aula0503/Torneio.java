package aula0503;

public class Torneio {
    String nome;
    int idade;

    public Torneio(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    String getNome() {
        return this.nome;
    }

    void setNome(String n) {
        this.nome = n;
    }

    int getIdade() {
        return idade;
    }

    void setIdade(int i) {
        this.idade = i;
    }
    
    String verificaCategoria(){
        if (this.getIdade() >= 5 && this.getIdade() <= 7) {
            return "Categoria: Infantil";
        }
        else if (this.getIdade() >= 8 && this.getIdade() <= 10) {
            return "Categoria: Juvenil";
        }
        else if (this.getIdade() >= 11 && this.getIdade() <= 15) {
            return "Categoria: Adolescente";
        }
        
        else if (this.getIdade() >= 16 && this.getIdade() <= 30) {
            return "Categoria: Adulto";
        }
        
        else if (this.getIdade() > 30) {
            return "Categoria: Senior";
        }
        
        return "Categoria: Não calculada";
    }
    
    void imprimeDados(){
        System.out.println("---- Torneio ----");
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade);
        System.out.println(verificaCategoria());
    }
    
    
}
