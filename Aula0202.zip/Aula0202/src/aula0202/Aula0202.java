
package aula0202;

import java.util.Scanner;


public class Aula0202 {


    public static void main(String[] args) {
      Produto prod = new Produto();
      prod.marca = "Motorola";
      prod.cod_barras = "231849723509825385";
      prod.fabricante = "Lenovo";
      prod.preco = 1250f;
      
      Scanner teclado = new Scanner(System.in);
      
      String marca, fabricante, codBarras;
      float preco;
      
      System.out.println("Digite a marca do Produto: ");
      marca = teclado.nextLine();
      
      System.out.println("Digite o fabricante do Produto: ");
      fabricante = teclado.nextLine();
      
      System.out.println("Digite o codigo de barras do Produto: ");
      codBarras = teclado.nextLine();
      
      System.out.println("Digite o preco do Produto: ");
      preco = teclado.nextFloat();
      
      Produto prod2 = new Produto(marca, fabricante, codBarras, preco);
      
      System.out.println("\nDados do primeiro produto: ");
      System.out.println("Marca: " + prod.marca);
      System.out.println("Fabricante: " + prod.fabricante);
      System.out.println("Codigo de barras: " + prod.cod_barras);
      System.out.println("Preco: " + prod.preco);
      
      System.out.println("\nDados do segundo produto: ");
      System.out.println("Marca: " + prod2.marca);
      System.out.println("Fabricante: " + prod2.fabricante);
      System.out.println("Codigo de barras: " + prod2.cod_barras);
      System.out.println("Preco: " + prod2.preco);
        
    }
    
}
