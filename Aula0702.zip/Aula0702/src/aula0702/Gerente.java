package aula0702;

public class Gerente extends Funcionario {
    private int senha;
    private int funcionariosGerenciados;
    
    public Gerente(){}
    
    public Gerente(int s, int fG){
        this.senha = s;
        this.funcionariosGerenciados = fG;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public int getFuncionariosGerenciados() {
        return funcionariosGerenciados;
    }

    public void setFuncionariosGerenciados(int fG) {
        this.funcionariosGerenciados = fG;
    }
    
    public double bonificacao(){
        double aumentoSal = super.getSalario() + (super.getSalario() * 0.15);
        return aumentoSal;
    }
    
    public boolean autentica() {
        int senhaBanco = 892021;
        
        if (this.getSenha() == senhaBanco) {
            return true;
        }
        
        return false;
    }
    
    
}
