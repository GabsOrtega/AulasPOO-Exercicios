package aula0702;

public class Caixa extends Funcionario {
    public Caixa(){}
    
    public double bonificacao(){
        double aumentoSal = super.getSalario() + (super.getSalario() * 0.10);
        return aumentoSal;
    }
}
