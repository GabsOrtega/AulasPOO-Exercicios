package aula0702;

public class Funcionario {
    private String nome;
    private String cpf;
    private double salario;
    
    public Funcionario(){}
    
    public Funcionario(String n, String c, double s){
        this.nome = n;
        this.cpf = c;
        this.salario = s;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public boolean autentica(){
        return true;
    }
    
    public double bonificacao(){
        return this.getSalario() + (this.getSalario() * 0.10);
    }
}
