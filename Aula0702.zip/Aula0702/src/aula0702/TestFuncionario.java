package aula0702;

import javax.swing.JOptionPane;

public class TestFuncionario {

    public static void main(String[] args) {
       Funcionario c = new Caixa();
       c.setNome(JOptionPane.showInputDialog("Digite o nome do Funcionario Caixa"));
       c.setCpf(JOptionPane.showInputDialog("Digite o Cpf do Funcionario Caixa"));
       c.setSalario(Double.parseDouble(JOptionPane.showInputDialog("Digite o salário do Funcionario Caixa")));
       
       Funcionario g = new Gerente();
       g.setNome(JOptionPane.showInputDialog("Digite o nome do Funcionario Gerente"));
       g.setCpf(JOptionPane.showInputDialog("Digite o Cpf do Funcionario Genrente"));
       g.setSalario(Double.parseDouble(JOptionPane.showInputDialog("Digite o salário do Funcionario Gerente")));
       ((Gerente)g ).setSenha(Integer.parseInt(JOptionPane.showInputDialog("Digite a senha do sistema interno")));
       ((Gerente)g ).setFuncionariosGerenciados(Integer.parseInt(JOptionPane.showInputDialog("Digite o número de funcionários gerenciados")));
       
       
       JOptionPane.showMessageDialog(null, "----- Caixa ----- \nNome: " + c.getNome() + "\nCpf: " + c.getCpf() + "\nSalário: " + c.getSalario()
               + "\n \n----- Gerente ----- \nNome: " + g.getNome() + "\nCpf: " + g.getCpf() + "\nSalário: " + g.getSalario() + "\nSenha digitada: " + ((Gerente)g).getSenha()
                       + "\nAcesso ao banco: " + ((Gerente)g).autentica()
                       + "\nGerenciados: " + ((Gerente)g).getFuncionariosGerenciados());
       
      
    }
    
}
