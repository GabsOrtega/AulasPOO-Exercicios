package aula0402;

public class Aula0402 {

    public static void main(String[] args) {
        Paciente p = new Paciente();
        Paciente p1 = new Paciente("Orteguinhas");
        p1.rg = "000.000.000-00";
        p1.endereco = "Rua sertao";
        p1.telefone = "11 99999-9999";
        p1.anoNascimento = 2000;
        p1.profissao = "Veterinario";
        
        p.cadastraDados();
        p.imprimeDados();
        
        
        p1.imprimeDados();
    }
    
}
