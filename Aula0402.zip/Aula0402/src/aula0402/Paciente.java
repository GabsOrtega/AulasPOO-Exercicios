package aula0402;

import java.util.Calendar;
import javax.swing.JOptionPane;

public class Paciente {
    String nome;
    String rg;
    String endereco;
    String telefone;
    int anoNascimento;
    String profissao;
    
    public Paciente(){}
    
    public Paciente(String n){
        this.nome = n;
    }
    
    void cadastraDados() {
        this.nome = JOptionPane.showInputDialog("Digite o nome do Paciente");
        
        this.rg = JOptionPane.showInputDialog("Digite o RG do Paciente");
        
        this.endereco = JOptionPane.showInputDialog("Digite o endereço do Paciente");
        
        this.telefone = JOptionPane.showInputDialog("Digite o telefone do Paciente");
        
        this.anoNascimento = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de nascimento do Paciente"));
        
        this.profissao = JOptionPane.showInputDialog("Digite a profissão do Paciente");

    }
    
    void imprimeDados(){
        Calendar data = Calendar.getInstance();
        System.out.println("\n---- Paciente ----");
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.calculaIdade(data.get(Calendar.YEAR)));
        System.out.println("RG: " + this.rg);
        System.out.println("Endereco: " + this.endereco);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Ano de Nascimento: " + this.anoNascimento);
        System.out.println("Profissao: " + this.profissao);
    }
    
    int calculaIdade(int anoAtual) {
        return anoAtual - this.anoNascimento;
    }
}
